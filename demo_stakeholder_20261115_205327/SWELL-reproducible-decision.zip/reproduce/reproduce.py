import math, json, numpy as np
from pathlib import Path
def simulate(z,dx,rain,capacity,drain,roughness=.04,suction_deficit_m=0.,dt=30.,outlet=None):
    """Depth-based diffusive routing: positive downhill flux in head, Manning friction.
    Outgoing volumes limited jointly to donor storage. Closed boundaries. Sources/sinks explicit.
    No momentum, rivers, sewer network, or subsurface pressure. Timesteps capped at 30 s.
    """
    z=np.asarray(z,dtype=float);h=np.zeros_like(z);cap=np.broadcast_to(capacity,z.shape);dr=np.broadcast_to(drain,z.shape);area=dx*dx
    if not np.isfinite(z).all() or min(dx,roughness)<=0 or not np.isfinite(cap).all() or not np.isfinite(dr).all() or np.any(cap<0) or np.any(dr<0):raise ValueError('Invalid solver inputs')
    if dt not in (30.,15.,10.,5.):raise ValueError('Unsupported timestep')
    if outlet is not None:
        row,col=int(outlet['row']),int(outlet['col']);stage=float(outlet['stage_m'])
        if not (0<=row<z.shape[0] and 0<=col<z.shape[1] and (row in (0,z.shape[0]-1) or col in (0,z.shape[1]-1))) or not math.isfinite(stage):raise ValueError('Outlet must be a boundary cell with finite external water elevation')
    total=inf=removed=outflow=0.;peak=h.copy();frames=[];mass=[];steps=int(3600/dt);F=np.zeros_like(h);limited=faces=0
    for r in rain:
        for _ in range(steps):
            add=r/1000/steps;h+=add;total+=add*h.size*area
            if suction_deficit_m>0:
                # Sharp wetting-front Green-Ampt integral with nonnegative available water.
                # For a continuous event, solve the ponded capacity and cap by available water.
                A=suction_deficit_m;target=cap/1000/steps;low=np.zeros_like(h);high=h.copy();
                possible=(h-A*np.log1p(h/(F+A)))<=target
                for _bisect in range(14):
                    mid=(low+high)*.5; ok=(mid-A*np.log1p(mid/(F+A)))<=target
                    low=np.where(ok,mid,low);high=np.where(ok,high,mid)
                take=np.where(cap<=0,0,np.where(possible,h,low))
            else:take=np.minimum(h,cap/1000/steps)
            h-=take;F+=take;inf+=take.sum()*area
            take=np.minimum(h,dr/1000/steps);h-=take;removed+=take.sum()*area
            head=z+h
            # square-grid face flux, from higher water surface, only above higher bed crest.
            def flow(a,b,za,zb):
                diff=a-b; depth=np.maximum(0,np.maximum(a,b)-np.maximum(za,zb));raw=depth**(5/3)*np.sqrt(np.abs(diff)/dx)/roughness*dx*dt/area
                # Limit head equalization per face to 1/8 difference (up to four neighbours).
                nonlocal limited,faces
                faces+=int(np.count_nonzero(raw));limited+=int(np.count_nonzero(raw>np.abs(diff)/8+1e-12));return np.sign(diff)*np.minimum(raw,np.abs(diff)/8)
            qx=flow(head[:,:-1],head[:,1:],z[:,:-1],z[:,1:]);qy=flow(head[:-1,:],head[1:,:],z[:-1,:],z[1:,:]);out=np.zeros_like(h)
            out[:,:-1]+=np.maximum(qx,0);out[:,1:]+=np.maximum(-qx,0);out[:-1,:]+=np.maximum(qy,0);out[1:,:]+=np.maximum(-qy,0)
            # additionally limit transfer to avoid overshoot in a single step (screening discretization)
            scale=np.minimum(1,np.divide(h*.25,out,out=np.ones_like(h),where=out>0));qx*=np.where(qx>=0,scale[:,:-1],scale[:,1:]);qy*=np.where(qy>=0,scale[:-1,:],scale[1:,:]);h[:,:-1]-=qx;h[:,1:]+=qx;h[:-1,:]-=qy;h[1:,:]+=qy
            if np.min(h)<-1e-10:raise ArithmeticError('Negative depth')
            if outlet is not None:
                # One-way outlet to specified downstream stage; no river inflow. Face width = dx.
                head_here=z[row,col]+h[row,col];delta=max(0,head_here-stage);wet=max(0,head_here-max(z[row,col],stage));q=wet**(5/3)*math.sqrt(delta/(dx/2))/roughness*dt/dx
                take=min(h[row,col],q,delta/4);h[row,col]-=take;outflow+=take*area
            peak=np.maximum(peak,h)
        stored=float(h.sum()*area);err=total-inf-removed-outflow-stored
        if abs(err)>max(1e-6,total*1e-9):raise ArithmeticError('Water budget failed')
        frames.append(h.copy());mass.append({'rain_m3':total,'infiltrated_m3':float(inf),'drained_m3':float(removed),'boundary_outflow_m3':float(outflow),'stored_m3':stored,'balance_error_m3':float(err),'max_depth_m':float(h.max()),'wet_area_m2':float(np.count_nonzero(h>=.05)*area),'limited_face_fraction':limited/max(1,faces)})
    return np.array(frames),peak,mass
if __name__ == '__main__':
    root=Path(__file__).resolve().parent
    r=json.loads((root/'scenario.json').read_text()); z=np.load(root/'elevation.npy',allow_pickle=False); i=r['inputs']; cap=np.full(z.shape,i['infiltration']); drain=np.zeros_like(z)
    for e in i['edits']:
        (drain if e['kind']=='drain' else cap)[e['row'],e['col']]=e['rate']
    args=(i['roughness'],i['suction_mm']*i['moisture_deficit']/1000)
    for label,c,d,key in [('baseline',i['infiltration'],0,'baseline'),('intervention',cap,drain,'scenario')]:
        f,p,m=simulate(z,r['site']['dx'],i['rain_mm_h'],c,d,*args,outlet=i.get('outlet'))
        error=float(np.max(np.abs(p-np.array(r[key+'_peak'])))); frame_error=float(np.max(np.abs(f-np.array(r[key+'_frames'])))); budget_error=abs(m[-1]['stored_m3']-r[key][-1]['stored_m3']); print(label,'peak max abs error m',error,'frame max abs error m',frame_error,'final storage error m3',budget_error)
        assert error<1e-8 and frame_error<=5.01e-6 and budget_error<1e-6,'Reproduction mismatch'
    print('Reproduced saved model, not field validation.')
